import numpy as np
#3.In una catena di montaggio abbiamo una struttura metallica di 28.75 cm di lunghezza; 
#per assicurarne la stabilità, è necessario inserire 15 rivetti,
#dei quali uno all'inizio e uno alla fine, e tutti quanti separati dalla stessa distanza; 
#come possiamo calcolare i punti esatti in cui inserire i rivetti tramite NumPy?

struttura=np.linspace(0,28.75,15) #linspace mi da 15 valori, equidistanziati, da 0 a 28.75
struttura=np.round(struttura, decimals=3)#arrotondo a 3 cifre decimali
print(struttura)