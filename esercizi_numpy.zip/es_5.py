#5.
import numpy as np

#prima creo il vettore
#poi calcolo il minimo e il massimo all'interno del vettore
#una volta trovato minimo e massimo, inizializzo una lista vuota
#creo un ciclo for che elemento per elemento nel vettore, fa l'operazione richiesta dalla consegna
#con lista.append aggiungo a ogni giro il nuovo elemento modificato
#trasformo la lista ottenuta in vettore
#trasformo il vettore in matrice
#stampo la matrice risultato
vettore=np.array([10,22,21,8,9,9,42,3,18,11,5,4,30,12,29,37,31,7,2,26,8,6,4,33,15])
minimo=vettore.min()
massimo=vettore.max()
lista=[]
for x in vettore:
    lista.append(float(x-minimo)/(massimo-minimo))

vettore_calcolato=np.array(lista)

matrice_risultato=vettore_calcolato.reshape((5,5))

print(matrice_risultato)











