import numpy as np
#4. 
vettore=np.ndarray([1,1,1,1,5,1,1,1,20,-4,0,42])
matrice=vettore.reshape((3,4)) # ho 12 elementi --> matrice 3X4
print(matrice)