import numpy as np

#2. Quante dimensioni ha?
linear_data = np.array([x for x in range(27)])
reshaped_data = linear_data.reshape((3,3,3))
#print(reshaped_data)

#       |
#       |
#       V
#otteniamo una matrice di 3 dimensioni. Abbiamo 3 matrici 3X3.

print(reshaped_data[1,1,1]) #accedo all'elemento 13