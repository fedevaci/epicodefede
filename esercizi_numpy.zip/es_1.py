import numpy as np

#1.se ad esempio voglio l'elemento 6 |
#                                  |
#                                  V
mat = [[0, 1, 2, 3, 4], [5, 6, 7, 8, 9], [10, 11, 12, 13, 14]]
mat = np.array(mat)
print(mat[1,1])


