#Scrivere una funzione che, data una lista di numeri, come output stamperà lo stesso numero di asterischi su righe diverse, ottenendo una semplice visualizzazione grafica

def stelline(lista):
    for i in range(0,len(lista)):
        limite=lista[i]
        for j in range(0,limite):
            print("*",end="")
        print("\n")
stampiamo_stelline=[1,6,18,21,30,50,5,7,10,28,61,20]

stelline(stampiamo_stelline)
