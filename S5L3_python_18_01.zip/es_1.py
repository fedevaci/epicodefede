#Scegliere almeno 3 esercizi del giorno precedente e riscriverli con un ciclo for invece che while
#1)prime 10 potenze di 2
print("Le seguenti sono le prime 10 potenze di 2: ")
for i in range(0,11):
    print("Potenza numero ",i," di 2: ",2**i)
#2)prime N potenze di 2
N=int(input("Ora, dammi un N e ti calcolerò le prime N potenze di 2: "))
for l in range(0,N+1):
    print("Potenza numero ",l," di 2: ",2**l)
#3)potenze di 2 minori di 25000
X=int(input("dammi un numero X e ti stamperò tutti i suoi divisori: "))
for m in range(X,0,-1):
    if (X%m==0):
        print(m)
    
        