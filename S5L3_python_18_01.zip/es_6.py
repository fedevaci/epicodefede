#Scrivere una funzione che, data una lista di numeri, fornisca in output i tre numeri più grandi; gestire il caso in cui la lista sia più corta di tre, e quando uno o più dei numeri selezionati sono uguali.
def tre_maggiori(lista):
    max1=0
    max2=0
    max3=0
    for i in range(0,len(lista)):
        if(lista[i]>max1) and (lista[i]>max2) and (lista[i]>max3):
            max3=max2
            max2=max1
            max1=lista[i]
        elif(lista[i]==max1):
            max2=lista[i]
        elif(lista[i]>max2) and (lista[i]>max3):
            max3=max2
            max2=lista[i]
        elif(lista[i]==max2):
            max3=lista[i]
        elif(lista[i]>max3):
            max3=lista[i]
    print("I 3 valori maggiori sono: ",max1,", ",max2,", ",max3)
        
lista_prova=[189,200,200,1083,14,55,155,1083,44,66,78,10,85,1,20,20523,11232,32,11,-65,-6,-32]

if len(lista_prova)>=3:
    tre_maggiori(lista_prova)
else:
    print("Dovresti inserire una lista più lunga, sennò non ha senso")