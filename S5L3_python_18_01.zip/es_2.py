#creiamo un dizionario che assegni ad ogni proprietario la sua auto. Stampare poi l'auto di Debbie


auto= {"Ada":"Punto","Ben":"Multipla","Charlie":"Golf","Debbie":"107"}
print(auto)
print("L'auto di Debbie è una: ",auto["Debbie"])