#Scrivere una funzione che, data una lista di numeri, fornisca in output il minimo e il massimo (possiamo usare o meno le funzioni min() e max() nel corpo).

def valoremassimo(lista):
    massimo=lista[0]
    for i in range(0,len(lista)):
        if lista[i]>massimo:
            massimo=lista[i]
    return massimo

def valoreminimo(lista):
    minimo=lista[0]
    for i in range(0,len(lista)):
        if lista[i]<minimo:
            minimo=lista[i]
    return minimo

lista1=[44,65,189,23,14,55,155,200,1083,44]
risultato_max=valoremassimo(lista1)
risultato_min=valoreminimo(lista1)
print("Il valore massimo della lista è: ",risultato_max,"e il valore minimo è: ",risultato_min)