#Abbiamo un dizionario che assegna ad ogni proprietario la sua auto:
#Con un ciclo, e usando il metodo .values(), stampiamo a video tutte le auto che non sono una Multipla.
dizionario_auto = {"Ada": "Punto", "Ben": "Multipla", "Charlie": "Golf", "Debbie": "107"}
for modello in dizionario_auto.values():
    if modello!="Multipla":
        print(modello)