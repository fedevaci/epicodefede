import pandas as pd

file_path='./iris.data'

dataset=pd.read_csv(file_path, header=None, names=['sepal length','sepal width','petal length','petal width','class'])

print(dataset.head())
print(dataset.tail(10))

print(dataset.describe(include='number'))

