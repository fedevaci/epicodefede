import pandas as pd
#Effettuiamo calcoliamo le informazioni statistiche base (numerosità, modie, mode, mediane, quartili, ecc) sulle colonne numeriche usando python

file_name='./wine.csv'

data=pd.read_csv(file_name, header=0, sep=',')
#print(data)
#dimensioni=data.shape
#print('La tabella ha ',dimensioni[0],' righe e',dimensioni[1], 'colonne')

#RICAVO DIVERSE INFORMAZIONI MATEMATICHE SULLO ZUCCHERO RESIDUO 
#                   |
#                   |
#                   V

#               MAX & MIN
minimo_zucchero_r=data['residual sugar'].min()
massimo_zucchero_r=data['residual sugar'].max()
print('MINIMO --> ',minimo_zucchero_r,"MASSIMO --> ",massimo_zucchero_r)

#                 MEDIA
media_zucchero_r=data['residual sugar'].mean()
media_zucchero_r=round(media_zucchero_r, 4)
print('QUANTITA MEDIA ZUCCHERO RESIDUO --> ',media_zucchero_r)

#                MEDIANA
mediana_zucchero_r=data['residual sugar'].median()
print('VALORE MEDIANO -->', mediana_zucchero_r)

#                QUARTILI
quartili_zucchero_r=data['residual sugar'].quantile([0.10,0.25,0.40,0.60,0.75,0.9])
print('PERCENTILI -->',quartili_zucchero_r)

#Notiamo che i valori dei percentili < 50 percentile hanno valori molto più ravvicinati tra loro
#questo è il motivo per cui abbiamo un valore mediano decisamente più basso rispetto al valore medio
