import numpy as np

#posizioni scacchiera bianco-nero
#scacchiera=np.ones((8,8), int)
#scacchiera[0::2, 0::2]=0
#scacchiera[1::2, 1::2]=0
#print(scacchiera)

#pezzi scacchiera

def creazione_scacchiera(scacchiera):
    scacchiera[1, 0:]='p'
    scacchiera[6, 0:]='p'
    scacchiera[0::7,0::7]='T'
    scacchiera[0::7,1::5]='H'
    scacchiera[0::7,2::3]='B'
    scacchiera[0,3]='Q'
    scacchiera[0,4]='K'
    scacchiera[7,3]='K'
    scacchiera[7,4]='Q'
    return scacchiera

def scelta_pezzo(scacchiera):
    print("Devi darmi le coordinate del pezzo da muvoere")
    y=int(input("Coordinata y: "))
    x=int(input("Coordinata x: "))
    lista=[y,x]
    return lista
     
def muovi_e_aggiorna(scacchiera, scelta):
    print("dove vuoi muovere il pezzo?: ")
    y2=int(input("Coordinata y: "))
    x2=int(input("Coordinata x: "))
    mossa=[y2,x2]
    y1=scelta[0]
    x1=scelta[1]
    scacchiera[y2,x2]=scacchiera[y1,x1]
    scacchiera[y1,x1]='0'
    return scacchiera

    

    
        


scacchiera=np.zeros((8,8), str)
scacchiera_iniziale=creazione_scacchiera(scacchiera)
print(scacchiera_iniziale)
gioco=[]
gioco=scacchiera_iniziale
conta=0
while conta<100:
    scelta=[]
    scelta=scelta_pezzo(gioco)
    gioco=muovi_e_aggiorna(gioco, scelta)
    print(gioco)
    conta+=1

