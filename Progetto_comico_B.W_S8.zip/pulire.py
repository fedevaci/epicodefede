import pandas as pd
#               ---IMPORTAZIONE E PULIIZA DEI DATI---


#creo delle variabili file che contenogno il percorso dei file
#                               |
#                               |
#                               V
file_comuni='./Comuni_python.csv'
file_rip='./Ripartizione_geografica_python.csv'
file_prov='./covid19_italy_province_python.csv'
file_reg='./covid19_italy_region_python.csv'
#prima di importare i file, elimino nel file "Comuni" i caratteri non UTF-8 che danno problemi al momento della lettura
#dopodiché uniformiamo i nomi delle regioni nei diversi file csv e di testo es. 'Trentino-Alto Adige/SudTirol' e 'Trentino-Alto Adige'
#vanno sotto l'unico nome di 'Trentino-Alto Adige'
#                               |
#                               |
#                               V
#importo i file e li metto all'interno di 4 dataframe grazie alla libreria pandas
#                               |
#                               |
#                               V
comuni = pd.read_csv(file_comuni)
ripartizioni=pd.read_csv(file_rip)
province = pd.read_csv(file_prov)
region = pd.read_csv(file_reg)
#pulisco le tabelle da colonne vuote, righe duplicate, righe vuote o con valori non conformi al dataset
#correggo i testi, settando le giuste maiuscole e minuscole
#                               |
#                               |
#                               V
comuni['Regione'] = comuni['Regione'].str.lower().str.capitalize()
comuni_clean=comuni.dropna(axis=1, how='all').drop_duplicates().dropna(how='all').drop(comuni.index[7919])
ripartizioni_clean=ripartizioni.dropna(how='all')

province_clean = province.dropna(how='all').drop_duplicates()
province_clean['Date']=pd.to_datetime(province_clean['Date'])
regioni_clean = region.dropna(how='all').drop_duplicates()
regioni_clean['Date']=pd.to_datetime(regioni_clean['Date'])
poveri_regione=pd.DataFrame()
poveri_regione= pd.read_csv('./poveri_regione.csv')
poveri_regione=poveri_regione.drop(columns=['FREQ','Frequenza','REF_AREA','DATA_TYPE','Indicatore','Tempo (TIME_PERIOD)','OBS_STATUS','Stato dell osservazione'])

#poveri_regione.to_csv('poveri_regione_clean.csv')
#una volta puliti i dataset, procediamo con l'esportazione, creando dei nuovi dataset che non presentano errori
#                                                   |
#                                                   |
#                                                   V

poveri_regione.to_csv('poveri_regione.csv')
comuni_clean.to_csv('comuni_clean.csv')
province_clean.to_csv('province_clean.csv')
regioni_clean.to_csv('regioni_clean.csv')
ripartizioni_clean.to_csv('ripartizioni_clean.csv')
