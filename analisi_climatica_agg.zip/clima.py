#Normalizzazione dei Dati: Pulire i dati per rimuovere eventuali valori mancanti o errati. 
#   Applicare la normalizzazione Z-score alla temperatura_media, precipitazioni, umidità e velocità_vento per standardizzarle.

import pandas as pd
import numpy as np
import seaborn as sea
from matplotlib import pyplot as pp 

file_dir='./dataset_climatico.csv'
tabella=pd.read_csv(file_dir)

#pulizia duplicati e nulli
#   |
#   |
#   V
tabella_pulita=tabella.dropna().drop_duplicates()

#controllo dei formati data_osservazione
#   |
#   |
#   V
tabella_pulita['data_osservazione']=pd.to_datetime(tabella_pulita['data_osservazione']).dt.date

#calcolo le deviazioni standard
#   |
#   |
#   V
std_temp=np.std(tabella_pulita['temperatura_media'])
std_prec=np.std(tabella_pulita['precipitazioni'])
std_umid=np.std(tabella_pulita['umidita'])
std_vento=np.std(tabella_pulita['velocita_vento'])

#calcolo lo Z score, ovvero quanto si discostano i dati dalla media rispetto alla deviazione standard: se ho valori vicino allo zero si discostano poco
#più mi allontano dallo zero e più vuol dire che sono distante dal valore medio
#faccio anche un "ADD COLUMN" per vedere come questi dati si leghino ad ogni riga
#   |
#   |
#   V

tabella_pulita['zscore_temp']= (tabella_pulita['temperatura_media']-tabella_pulita['temperatura_media'].mean())/std_temp
tabella_pulita['zscore_precipitazioni']= (tabella_pulita['precipitazioni']-tabella_pulita['precipitazioni'].mean())/std_prec
tabella_pulita['zscore_umid']= (tabella_pulita['umidita']-tabella_pulita['umidita'].mean())/std_umid
tabella_pulita['zscore_vento']= (tabella_pulita['velocita_vento']-tabella_pulita['velocita_vento'].mean())/std_vento

#vogliamo trovare le statistiche princpiali sul dataset per ogni colonna: media, mediana, max, quartili...-->utilizzo il describe()
#   |
#   |
#   V

statistiche=tabella_pulita[['temperatura_media','precipitazioni','umidita','velocita_vento']].describe()
print(statistiche)

#Creo un grafico per visualizzare la distribuzione della variabili normalizzate, osservo quanti valori e di quanto si distaccano dalla media
#   |
#   |
#   V
pp.figure(figsize=(15,10))
pp.subplot(2, 2, 1)
pp.hist(tabella_pulita['zscore_temp'], bins=30, color='red', edgecolor='black', alpha=0.5)
pp.title('Temperature')

pp.subplot(2, 2, 2)
pp.hist(tabella_pulita['zscore_precipitazioni'], bins=30, color='c', edgecolor='black', alpha=0.5)
pp.title('Precipitazioni')

pp.subplot(2, 2, 3)
pp.hist(tabella_pulita['zscore_umid'], bins=30, color='b', edgecolor='black', alpha=0.5)
pp.title('Umidità')

pp.subplot(2, 2, 4)
pp.hist(tabella_pulita['zscore_vento'], bins=30, color='purple', edgecolor='black', alpha=0.5)
pp.title('Vento')

pp.show()

#Adesso vogliamo vedere se esista o meno una correlazione tra le varie colonne es. temperatura-umidità, utilizzando l'hitmap
#   |
#   |
#   V
sea.heatmap(tabella_pulita[['temperatura_media','precipitazioni','umidita','velocita_vento']].corr(), annot=True, cmap='coolwarm', annot_kws={"size": 15})
pp.title('Correlazione tra variabili meteorologiche')
pp.show()
#   |
#   |
#   V
# come possiamo vedere dall'ultimo grafico, i dati non hanno correlazione, quindi capiamo che sono dati random e che non hanno alcun senso, dato che a precipitazioni
#alte, dovebbe corrispondere anche un'umidità alta
#soprattutto in zone come Torino, in pianura padana, dovremmo avere umidità elevate con alte temperature.

#vediamo un risultato similare con la rappresentazione con box plot --> valori distribuiti troppo uniformemente 
pp.figure(figsize=(10, 6))
sea.boxplot(data=tabella_pulita[['zscore_temp', 'zscore_precipitazioni', 'zscore_umid', 'zscore_vento']])
pp.xlabel('Variabile')
pp.ylabel('Valore normalizzato Z-score')
pp.title('Box Plot delle variabili normalizzate')
pp.show()
