#Stampare ogni carattere della stringa, uno su ogni riga, utilizzando un costrutto while.
nome_scuola="Epicode"
lunghezza=len(nome_scuola)
i=0
while i<lunghezza:
    print(nome_scuola[i])
    i+=1