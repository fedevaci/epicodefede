#Calcola tutti i divisori di un numero inserito dall'utente
print("Dammi un numero e ti darò tutti i suoi divisori: ")
x=int(input())
y=x
while y>0:
    if (x%y)==0:
        print(y)
    y-=1



