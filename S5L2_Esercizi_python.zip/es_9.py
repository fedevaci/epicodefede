#Dato un numero K calcolare le sue prime N potenze
print("Dammi un numero: ")
K=int(input())
print("Fino a che potenza (esponente) vuoi calcolare per questo numero: ")
N=int(input())
i=0
while i<=N:
    print(K**i)
    i+=1



