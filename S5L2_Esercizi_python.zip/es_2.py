#Stampare a video tutti i numeri da 0 a 20 utilizzando il costrutto while.
i=0
while i<=20:
    print(i)
    i+=1