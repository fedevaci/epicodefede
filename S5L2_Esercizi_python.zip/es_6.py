#verificare se studenti e rispettivi corsi che ci vengono chiesti sono inseriti; successivamente, se le due liste sono di egual lunghezza
studenti = ["Alex", "Bob", "Cindy", "Dan", "Emma", "Faith", "Grace", "Henry"]
corsi = ["Cybersecurity", "Data Analyst", "Backend", "Frontend", "Data Analyst", "Backend"]
studenti.append("Frontend")
studenti.append("Cybersecurity")
if len(studenti)==len(corsi):
    print("Ok le liste sono della stessa lunghezza")
else:
    print("ups!")


