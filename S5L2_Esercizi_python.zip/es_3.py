#Calcolare e stampare tutte le prime 10 potenze di 2 (e.g., 2⁰, 2¹, 2², …) utilizzando un ciclo while.
i=0
x=2
while i<=10:
    print(x**i)
    i+=1