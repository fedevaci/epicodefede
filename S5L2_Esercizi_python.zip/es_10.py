#Abbiamo una lista con i guadagni degli ultimi 12 mesi: usando un costrutto while, calcolare la media dei guadagni e stamparla a video.
guadagni=[100,90,70,40,50,80,90,120,80,20,50,50]
i=0
somma=0
while i<12:
    somma=somma+guadagni[i]
    i+=1
print("La media di guadagni mensili è: ",somma/12)




