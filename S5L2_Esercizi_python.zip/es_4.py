#Calcolare e stampare tutte le prime N potenze di 2 utilizzando un ciclo while, domandando all'utente di inserire N.
i=0
x=2
print("Calcola le prime N potenze di 2, dammi un N: ")
N=int(input())
while i<=N:
    print(x**i)
    i+=1


