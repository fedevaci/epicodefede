#Calcolare e stampare tutte le potenze di 2 minori di 25000.
i=0
x=2
while x**i<25000:
    print(x**i)
    i+=1 