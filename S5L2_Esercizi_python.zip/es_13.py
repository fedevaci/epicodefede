#Stampare a video tutti e soli gli studenti che frequentano una prima edizione; non tutti i dati potrebbero essere necessari.
#Riuscite a vedere una similarità con la logica che si usa in SQL e le tabelle relazionali?

studenti = ["Alex", "Bob", "Cindy", "Dan", "Emma", "Faith", "Grace", "Henry"] 
corsi = ["Cybersecurity", "Data Analyst", "Backend", "Frontend", "Data Analyst", "Backend", "Frontend", "Cybersecurity"] 
edizioni = [1, 2, 3, 2, 2, 1, 3, 3]
i=0
l=len(edizioni)
print("Gli studenti che sono alla prima edizione sono: ")
while i<l:
    if(edizioni[i]==1):
        print(studenti[i])
    i=i+1