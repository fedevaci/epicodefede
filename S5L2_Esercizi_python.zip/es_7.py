#Scriviamo un programma che chiede in input all'utente una stringa e visualizza i primi 3 caratteri, seguiti da 3 punti di sospensione e quindi gli ultimi 3 caratteri (Stavolta facciamo attenzione a tutti i casi particolari, ovvero implementare soluzioni ad hoc per stringhe di lunghezza inferiore a 6 caratteri)
print("Scrivi una frase a piacimento: ")
frase=input()
contatore=0
if len(frase)<=5:
    if len(frase)==5 or len(frase)==4:
        print(frase[0:2],"...",frase[-2:])
    elif len(frase)==3 or len(frase)==2:
        print(frase[0:1],"...",frase[-1:])
    elif len(frase)==1 or len(frase)==0:
        print("La tua frase è troppo corta, se vuoi sperimentare meglio l'algoritmo, inseriscine una più lunga")
        print("tua frase= ",frase)
else: 
    print(frase[0:3],"...",frase[-3:])



