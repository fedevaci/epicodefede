#trovare i codici fiscali che contengono "95", metterli in una lista, e alla fine stamparla; inoltre, per ognuno di essi, stampare a video i caratteri relativi al nome e quelli relativi al cognome.
lista_cf = ["ABCDEF95G01A123B", "GHIJKL91M02A321C", "MNOPQR89S03A456D", "STUVWX95Z04A654E", "XYZABC01D05A789F", "DEFGHI95J06A987G"]
lunghezza=len(lista_cf)
i=0
while i<lunghezza:
    if "95" in lista_cf[i]:
        print(lista_cf[i])
    i+=1




