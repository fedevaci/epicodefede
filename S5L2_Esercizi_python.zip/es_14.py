#Abbiamo una lista di stringhe di prezzi in dollari, che erroneamente sono stati scritti con il simbolo dell'euro
prezzi = ["100 €", "200 €", "500 €", "10 €", "50 €", "70 €"]
i=0
l=len(prezzi)
while i<l:
    prezzi[i]=prezzi[i].replace("€","$")
    i+=1
print(prezzi)