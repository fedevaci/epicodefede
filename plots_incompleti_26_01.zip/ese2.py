from matplotlib import pyplot as pp
import pandas as pan

file_name='./stockdata.csv'

data=pan.read_csv(file_name)
apple=pan.DataFrame()
apple=data.loc[0:19,['AAPL','Date']]
#print(apple)
pp.plot(apple.loc[:,'Date'], apple.loc[:,'AAPL'], linewidth=2, linestyle='--', color='r', marker='o', markerfacecolor='black')
pp.xlabel('Data')
pp.ylabel('Valore')
pp.title('Azioni Apple', )
pp.xticks(rotation=45)
pp.show()