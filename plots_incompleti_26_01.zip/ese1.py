from matplotlib import pyplot as pp
import pandas as pan

file_name='./stockdata.csv'

#mi importo il file, che precedentemente ho spostato nell'ambiente corrente
#python_25_01

# in questo primo dataframe, ho tutte le colonne e tutte le righe di stockdata.csv
#       |
#       |
#       V
microsoft_data=pan.read_csv(file_name)

#qua invece inizializzo un dataframe dove andrò a selezionare solo le colonne richieste
#       |
#       |
#       V
azioni_microsoft=pan.DataFrame()
azioni_microsoft=microsoft_data.loc[:, ['MSFT','Date']]
#help(microsoft_data.loc)

#tramite head e tail mi vado a selezionare le prime 5 e le ultime 5 righe
#       |
#       |
#       V

testa=pan.DataFrame()
coda=pan.DataFrame()
testa=azioni_microsoft.head()
coda=azioni_microsoft.tail()

#mi creo il grafico tramite plot, divido il risultato grafico in due segmenti
#uno che mi rappresenta la testa e uno che mi rappresenta la coda
#       |
#       |
#       V
pp.plot(testa.loc[:,'Date'], testa.loc[:,'MSFT'], color='c', linestyle='-', marker='*', linewidth=3, markersize=7)
pp.plot(coda.loc[:,'Date'], coda.loc[:,'MSFT'], color='g', linestyle='-', marker='*', linewidth=3, markersize=7)

#adesso vado a creare le parti descrittive del grafico
#etichette, titolo, legenda e griglia e infine lo stampo a video
#       |
#       |
#       V
pp.title("Analisi delle azioni Microsoft", color='r')
pp.xlabel("Date", color='y')
pp.ylabel("Miliardi di dollari", color='y')
pp.legend(['2007','2023'])
pp.grid(True)
pp.show()
#help(pp.plot)