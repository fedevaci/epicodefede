from matplotlib import pyplot as pp
import pandas as pan
import numpy as np
file_name='./stockdata.csv'

data=pan.read_csv(file_name)

#pp.plot(data.loc[:,'Date'], data.loc[:,['AAPL','MSFT','IBM','SBUX']], linewidth=2, linestyle='--', color='r', marker='o', markerfacecolor='black')
fig, ax = pp.subplots()

ax.plot(data.loc[:,'Date'], data.loc[:,'AAPL'], linewidth=2, linestyle='-', color='lightgrey')
ax.plot(data.loc[:,'Date'], data.loc[:,'MSFT'], linewidth=2, linestyle='-', color='g')
ax.plot(data.loc[:,'Date'], data.loc[:,'IBM'], linewidth=2, linestyle='-', color='b')

ax.set(xlim=(0, 2306), xticks=np.arange(0, 2306, 250),
       ylim=(0, 250), yticks=np.arange(0, 250, 25))
pp.title('Azioni 2007-2016 delle 3 compagnie',color='r')
pp.xlabel('Tempo')
pp.ylabel('Miliardi di €')
pp.legend(['Apple','Microsoft','IBM'],loc='lower right')
pp.grid(color='c')

#help(pp.legend)
pp.show()