from matplotlib import pyplot as pp
import pandas as pan
import numpy as np

file_name='./election.csv'

data=pan.read_csv(file_name)
data_agg=pan.DataFrame()
data_agg=data.iloc[:,[1,2,3,4]]
Voti_C=data_agg.iloc[:,0].sum()
Voti_B=data_agg.iloc[:,1].sum()
Voti_J=data_agg.iloc[:,2].sum()

pp.bar([data_agg.iloc[:,0],data_agg.iloc[:,1],data_agg.iloc[:,2]], height=150000)
print(Voti_C,' ',Voti_B,' ',Voti_J)
pp.show()
#pp.bar(data_agg.iloc[1],)
#pp.show()
#print(data_agg)
